package tw.ispan.action;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Demo13EtfData {
	private Connection conn;
	
	public void createConnection() throws Exception {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		String urlStr = "jdbc:sqlserver://localhost:1433;databaseName=JDBCDemoDB;"
				+ "user=sa;password=P@ssw0rd!;trustServerCertificate=true";
		this.conn = DriverManager.getConnection(urlStr);
		
		boolean status = !conn.isClosed();
		
		if(status) {
			System.out.println("開啟連線成功");
		}
		
	}
	
	public void closeConnection() throws Exception {
		if(conn != null) {
			conn.close();
			System.out.println("成功關閉連線");
		}
	}

	public void insertData(URL url) throws IOException, SQLException {
			try(InputStream is = url.openStream();
					BufferedInputStream bis = new BufferedInputStream(is);
					InputStreamReader isr = new InputStreamReader(bis,"UTF-8");
					BufferedReader br = new BufferedReader(isr);
					){
			br.readLine();
			String line = null;
			int time = 0;
			while((line = br.readLine())!=null) {
				String[] splitline = line.split(",");
				String sql = "insert into etf_V(stock_id,stock_name,month_quantity) values(?,?,?)";
				PreparedStatement preState = conn.prepareStatement(sql);
				preState.setString(1,splitline[1]);
				preState.setString(2,splitline[2]);
				preState.setString(3,splitline[3]);
//				for(int j=0;j <= 3;j++) {
//					preState.setString(j+1,splitline[j]);
//					
//				}
				preState.executeUpdate();
				preState.close();
				time++;
			}	
			System.out.println("insert finish");
			System.out.println("add " + time + " numbers of data");
			}catch (Exception e) {
			e.printStackTrace();
			}
	}
	
	public void getData() throws SQLException, IOException {
		System.out.print("enter the file name:");
		String enter = (new Scanner(System.in)).nextLine();
		String filePath = "D:\\JDBC\\workspace\\" + enter + ".csv"; 
		String sqlSelect = "select * from ETF_V where id = ?";
		PreparedStatement preState = conn.prepareStatement(sqlSelect);
		File file = new File(filePath);
//		File file = new File("D:\\JDBC\\workspace\\takeout2.csv");
		FileOutputStream fos = new FileOutputStream(file);
		OutputStreamWriter osw = new OutputStreamWriter(fos,"UTF8");
		
		for(int i = 1;i<=234;i++) {
			preState.setInt(1, i);
			ResultSet rs = preState.executeQuery();
			while(rs.next()) {
				String result = rs.getString(1)+","+rs.getString(2)+","+rs.getString(3)+","+rs.getString(4)+"\n";
				System.out.print(result);
				osw.write(result);
				osw.flush();
			}
		}
		osw.close();
		fos.close();
		preState.close();
		
		
		
		
	}
	public static void main(String[] args) {
		Demo13EtfData demo13 = new Demo13EtfData();
		try {
//			URL url = new URL("https://opendata.tdcc.com.tw/getOD.ashx?id=2-41");
			demo13.createConnection();
//			demo13.insertData(url);
			demo13.getData();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				demo13.closeConnection();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
	}
}
