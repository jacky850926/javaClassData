package tw.ispan.model;

public class Member {
	
	private Integer memberid;
	
	private String memberName;

	private String memberAddress;
	
	private String phone;
	
	//一定要有空的建構子，才能new空的memmber
	public Member() {
		
	}

	public Integer getMemberid() {
		return memberid;
	}

	public Member(Integer memberid, String memberName, String memberAddress, String phone) {
		super();
		this.memberid = memberid;
		this.memberName = memberName;
		this.memberAddress = memberAddress;
		this.phone = phone;
	}

	public void setMemberid(Integer memberid) {
		this.memberid = memberid;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getMemberAddress() {
		return memberAddress;
	}

	public void setMemberAddress(String memberAddress) {
		this.memberAddress = memberAddress;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}


}
