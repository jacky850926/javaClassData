package tw.ispan.model;

import java.sql.SQLException;
import java.util.List;

public class Demo12DaoAction {

	public static void main(String[] args) {
		//DAO與商業邏輯分開
		MemberDao mDao = new MemberDao();
		
		//商業邏輯
//		Member m1 = new Member(1004,"JJ","Malaysia","129456");
		//沒有建構子的話就只能建立空的用set帶入
		
		try {
			mDao.createConnection();
//			mDao.addMember(m1);
//			Member resultMember = mDao.findMemberById(1001);
//			System.out.println(resultMember.getMemberName());
			
			List<Member> allMember = mDao.getAllMember();
			for(Member tempMember : allMember) {
				System.out.println("name :" + tempMember.getMemberName());
				System.out.println("address: " + tempMember.getMemberAddress());
				System.out.println("========================");
			}
//			mDao.updateAddressById(1001, "Mars");
//			
//			mDao.deleteById(1001);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				mDao.closeConnection();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
	}

}
