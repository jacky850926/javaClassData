package electScooterProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DataDao {
	
	private Connection conn;
	
	public void createConnection() throws SQLException {
		String urlStr = "jdbc:sqlserver://localhost:1433;databaseName=eletricscooter;"
				+ "user=sa;password=P@ssw0rd!;trustServerCertificate=true";
		this.conn = DriverManager.getConnection(urlStr);
		
		boolean status = !conn.isClosed();
		if(status) {
			System.out.println("開啟連線成功");
		}
	}
	
	public void closeConnection() throws SQLException {
		if(conn != null) {
			conn.close();
			System.out.println("成功關閉連線");
		}
	}
	
	
	public void addData(Data d) throws SQLException{
		String sql = "insert into tabletest2(dis,sta,address,das,state,cha,fee,way,ope,sty,no)"
				+ "values(?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement preState = conn.prepareStatement(sql);
//		preState.setString(1, d.getTable());
		preState.setString(1, d.getDis());
		preState.setString(2, d.getSta());
		preState.setString(3, d.getAddress());
		preState.setString(4, d.getDas());
		preState.setString(5, d.getState());
		preState.setString(6, d.getCha());
		preState.setString(7, d.getFee());
		preState.setString(8, d.getWay());
		preState.setString(9, d.getOpe());
		preState.setString(10, d.getSty());
		preState.setString(11, d.getNo());
		preState.execute();
		preState.close();
		System.out.println("新增資料完成");
		
	}
}
