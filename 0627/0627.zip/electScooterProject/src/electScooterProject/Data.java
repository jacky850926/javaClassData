package electScooterProject;

public class Data {
	//table屬於哪個表格
	private String table;
	//dis行政區
	private String dis;
	//sta站名
	private String sta;
	//address地址
	private String address;
	//das類別
	private String das;
	//state充電站狀況
	private String state;
	//cha是否收費
	private String cha;
	//fee充電費用
	private String fee;
	//way收費機制
	private String way;
	//ope是否對外開放
	private String ope;
	//sty充電座形式
	private String sty;
	//no充電插座數
	private String no;
	
	public Data() {
		
	}
	
	
	public Data(String table, String dis, String sta, String address, String das, String state, String cha, String fee, String way,
			String ope, String sty, String no) {
		super();
		this.table = table;
		this.dis = dis;
		this.sta = sta;
		this.address = address;
		this.das = das;
		this.state = state;
		this.cha = cha;
		this.fee = fee;
		this.way = way;
		this.ope = ope;
		this.sty = sty;
		this.no = no;
	}

	public String getTable() {
		return table;
	}


	public void setTable(String table) {
		this.table = table;
	}


	public String getDis() {
		return dis;
	}



	public void setDis(String dis) {
		this.dis = dis;
	}



	public String getSta() {
		return sta;
	}



	public void setSta(String sta) {
		this.sta = sta;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getDas() {
		return das;
	}



	public void setDas(String das) {
		this.das = das;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	public String getCha() {
		return cha;
	}



	public void setCha(String cha) {
		this.cha = cha;
	}



	public String getFee() {
		return fee;
	}



	public void setFee(String fee) {
		this.fee = fee;
	}



	public String getWay() {
		return way;
	}



	public void setWay(String way) {
		this.way = way;
	}



	public String getOpe() {
		return ope;
	}



	public void setOpe(String ope) {
		this.ope = ope;
	}



	public String getSty() {
		return sty;
	}



	public void setSty(String sty) {
		this.sty = sty;
	}



	public String getNo() {
		return no;
	}



	public void setNo(String no) {
		this.no = no;
	}




}
