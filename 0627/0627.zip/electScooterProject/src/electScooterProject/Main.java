package electScooterProject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class Main {

	public static void main(String[] args) {
		DataDao d1 = new DataDao();
		File file = new File("C:\\Java\\新北市電動機車充電站.csv");
		try(FileReader fr = new FileReader(file);
				BufferedReader br = new BufferedReader(fr);
				) {
			d1.createConnection();
			br.readLine();
			String line = null;
			while((line = br.readLine())!=null) {
				String[] splitline = line.split(",");
				Data m = new Data();
				m.setDis(splitline[0]);
				m.setSta(splitline[1]);
				m.setAddress(splitline[2]);
				m.setDas(splitline[3]);
				m.setState(splitline[4]);
				m.setCha(splitline[5]);
				m.setFee(splitline[6]);
				m.setWay(splitline[7]);
				m.setOpe(splitline[8]);
				m.setSty(splitline[9]);
				m.setNo(splitline[10]);
				d1.addData(m);
			}
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e2) {
			e2.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				d1.closeConnection();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

}
