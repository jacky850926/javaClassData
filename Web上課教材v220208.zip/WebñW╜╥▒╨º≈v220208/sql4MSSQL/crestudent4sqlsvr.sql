use DemoLab;

create table jwstudent (
id       varchar(10) not null,
name      varchar(10),
birthyear varchar(3),
birthmonth varchar(2),
birthday   varchar(2),
zipcode    varchar(3),
address    varchar(50),
phone      varchar(15),
mailaddress varchar(20)
);