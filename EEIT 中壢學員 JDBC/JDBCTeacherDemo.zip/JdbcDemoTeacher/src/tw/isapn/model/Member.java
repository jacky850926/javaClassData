package tw.isapn.model;

public class Member {

	private Integer memberId;

	private String memberName;

	private String memberAddress;

	private String phone;

	public Member() {
	}

	public Member(Integer memberId, String memberName, String memberAddress, String phone) {
		super();
		this.memberId = memberId;
		this.memberName = memberName;
		this.memberAddress = memberAddress;
		this.phone = phone;
	}

	public Member(String memberName, String memberAddress) {
		super();
		this.memberName = memberName;
		this.memberAddress = memberAddress;
	}

	public Integer getMemberId() {
		return memberId;
	}

	public void setMemberId(Integer memberId) {
		this.memberId = memberId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getMemberAddress() {
		return memberAddress;
	}

	public void setMemberAddress(String memberAddress) {
		this.memberAddress = memberAddress;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

}
