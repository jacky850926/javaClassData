package tw.ispan.action;

import java.util.List;

import tw.ispan.model.EtfDao;
import tw.ispan.util.GetDataUtil;

public class Demo1Action {

	public static void main(String[] args) {
		GetDataUtil getDataUtil = new GetDataUtil();
		
		EtfDao dao = null;
		
		 try {
			List<String> dataList = getDataUtil.getURLContent();
			
			// 觀察第一筆資料(移除過標頭的)
//			String[] tokens = dataList.get(0).split(",");
//			
//			System.out.println("=====一筆資料===================");
//	        // 拿到 證券代號, 證券名稱, 集保量
//			System.out.println("證券代號: " + tokens[1]); // 0050
//			System.out.println("證券名稱: " + tokens[2]); 
//			System.out.println("集保量:  " + tokens[3]);
//			System.out.println("========================");
			
			
			// 確認完資料後開始裝資料
			dao = new EtfDao();
			
			dao.createConn();
			
			for (int i = 0; i < dataList.size(); i++) {
				String[] tokens1 = dataList.get(i).split(",");
				System.out.println("正要輸入: " + tokens1[1] + tokens1[2] + tokens1[3]);
				dao.insertEtfData(tokens1[1], tokens1[2], Integer.parseInt(tokens1[3]));
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
		} finally {
			try {
				dao.closeConn();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

}
