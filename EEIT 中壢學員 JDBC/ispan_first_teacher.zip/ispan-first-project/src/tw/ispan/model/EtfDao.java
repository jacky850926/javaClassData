package tw.ispan.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EtfDao {
	
	private Connection conn;
	
	public Connection createConn() throws Exception{
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		String urlStr = "jdbc:sqlserver://localhost:1433;databaseName=JDBCDemoDB;user=sa;password=P@ssw0rd!;trustServerCertificate=true";
		this.conn = DriverManager.getConnection(urlStr);
		
		boolean status = !conn.isClosed();
		
		if(status) {
			System.out.println("連線開啟");
		}
		
		return conn;
		
	}
	
	public void closeConn() throws Exception {
		if(conn != null) {
			conn.close();
			System.out.println("Connection Closed !!");
		}
	}
	
	public void insertEtfData(String stockId, String stockName, int stockQuantity) throws SQLException {
		String sqlStr = "Insert into ETF_V(stock_id, stock_name, month_quantity) Values(?,?,?)";
		PreparedStatement preState = conn.prepareStatement(sqlStr);
		preState.setString(1, stockId);
		preState.setString(2, stockName);
		preState.setInt(3, stockQuantity);
		preState.execute();
		preState.close();
		System.out.println("Insert Data OK!!");
	}

}
