package tw.ispan.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class GetDataUtil {
	
	public List<String> getURLContent() throws IOException {
		String etf = "https://opendata.tdcc.com.tw/getOD.ashx?id=2-41";
		ArrayList<String> list = new ArrayList<String>();

		URL url = new URL(etf);
		InputStream inStream = url.openStream();
		InputStreamReader inputReader = new InputStreamReader(inStream, "UTF-8");
		BufferedReader bReader = new BufferedReader(inputReader);
		

		try {

			String content = "";

			// 看資料
			while (bReader.ready()) {
				content = bReader.readLine();
//					System.out.println(content);
				list.add(content); // 加到 list 裡面
			}

			// 刪除第一筆
			list.remove(0);

			// 看全部資料要打開
//			System.out.println("清理完第一筆後: ");
//			for (String oneRow : listAQI) {
//				System.out.println("oneRow: " + oneRow);
//			}

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} finally {
			bReader.close();
			inputReader.close();
		}
		return list;
	}

}
