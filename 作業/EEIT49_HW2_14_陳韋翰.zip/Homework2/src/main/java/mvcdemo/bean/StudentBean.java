package mvcdemo.bean;

import java.io.Serializable;

public class StudentBean implements Serializable {
	private String name;
	private String school;
	private String department;
	private String gender;
	private String[] vehicle;
	
	public StudentBean() {
	}

	public StudentBean(String name, String school, String department, String gender, String[] vehicle) {
		this.name = name;
		this.school = school;
		this.department = department;
		this.gender = gender;
		this.vehicle = vehicle;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String[] getVehicle() {
		return vehicle;
	}

	public void setVehicle(String[] vehicle) {
		this.vehicle = vehicle;
	}
	
	
}
