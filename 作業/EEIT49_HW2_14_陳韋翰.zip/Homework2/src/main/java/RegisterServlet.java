

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvcdemo.bean.StudentBean;

/**
 * Servlet implementation class Testservlet2
 */
@WebServlet(
		urlPatterns = { "/RegisterServlet" }
)
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		
		
		if(request.getParameter("submit")!=null) {
			submit(request, response);
		}else if(request.getParameter("confirm")!=null) {
			System.out.println("123");
			confirm(request, response);
		}
		

	}
	
	public void submit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name;
		String school;
		String department;
		String gender;
		String[] vehicle;
		
		name = request.getParameter("name");
		school = request.getParameter("school");
		department = request.getParameter("department");
		gender = request.getParameter("gender");
		vehicle = request.getParameterValues("vehicle");
		
		StudentBean regStudent = new StudentBean(name, school, department, gender, vehicle);
		request.getSession(true).setAttribute("regStudent", regStudent);
		request.getRequestDispatcher("/DisplayStudent.jsp").forward(request, response);
		
	}
	
	public void confirm(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
		request.getSession(true).invalidate();
		request.getRequestDispatcher("/Thanks.jsp").forward(request, response);
	}
	
}
