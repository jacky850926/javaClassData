

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Testservlet2
 */
@WebServlet(
		urlPatterns = { "/result" }, 
		initParams = { 
				
		})
public class RegisterFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterFormServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");   
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		String title = "報名資料確認";
		
		String name = request.getParameter("name");
		String school = request.getParameter("school");
		String department = request.getParameter("department");
		String gender = request.getParameter("gender");
		String[] vehicle= request.getParameterValues("vehicle");
		

		  
		out.println(			  
			       "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 " +
			       "Transitional//EN\n" +
	               "<HTML>\n" +
	               "<HEAD><TITLE>" + title + "</TITLE></HEAD>\n" +
		           "<BODY BGCOLOR=\"#FDF5E6\">\n" +
		           "<H1 ALIGN=CENTER>" + title + "</H1>\n" +
		           "<UL>\n" +
		           "  <LI>姓名:<br> "
		           + name + "\n" +
		           "  <LI>畢業學校:<br> "
		           + school + "\n" +
		           "  <LI>畢業科系:<br> "
		           + department + "\n" +
		           "  <LI>性別:<br> "
		           + gender + "\n" +
		           "  <LI>交通工具: <br>"
		           );
		for(String ve:vehicle) {
			out.println(ve+"<br>");
		}
		
		out.println(
		           "</UL>\n" +
		           "</BODY></HTML>");	
	}
	

}
